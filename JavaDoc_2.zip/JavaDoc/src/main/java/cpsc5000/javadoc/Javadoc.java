
package cpsc5000.javadoc;

import java.awt.HeadlessException;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JList;

/**
 *
 * @author Javadoc Group
 */
public class Javadoc {

    public static void main(String[] args) throws HeadlessException, IOException {

        Scanner input = new Scanner(System.in);
        // Path
        String path = "/Users/Nafiseh/Desktop/cpsc5000/a/lib";
        int choice = 0;

        while (choice != 7) {

            String menu = JOptionPane.showInputDialog("Please select the number of your option:\n"
                +"1. Create user account\n"
                +"2. Load user account\n"
                +"3. Create character\n"
                +"4. Display character\n "
                +"5. Save character\n"
                +"6. Load character\n"
                +"7. Exit"
                +"8. Select Race");
                    

            choice = Integer.parseInt(menu);

            // loop over menu
            if (choice == 1) {
                String userName = JOptionPane.showInputDialog("Please enter your user name.");
                File userFile = new File(path + userName + ".txt");
                if (userFile.exists()) {
                    System.out.println("This user name already exists. Please choose another user name");
                    continue;
                }
                String password = JOptionPane.showInputDialog("Please, enter your password.");
                String emailAddress = JOptionPane.showInputDialog("Please enter your email address.");

                User user = new User(userName, password, emailAddress);
                user.saveUser(path);
                continue;
            }

            if (choice == 2) { // load user account
                String username = JOptionPane.showInputDialog("Please enter your user name.");
                System.out.println("User = " + username);
                User user = new User();
                user.loadUser(username, path);
                continue;
            }

            if (choice == 3) { // create character
                {
                    String name = JOptionPane.showInputDialog("Please insert your character name.");
                    String gender = JOptionPane.showInputDialog("Please select character gender(M or F).");

                    int option = 0;
                    while (option == 0) {
                        String menu_2 = JOptionPane
                                .showInputDialog("Please select one of this method for assigning ability scores" + "\n"
                                        + "1 - Method 1 = Sum of 3d6. Min/Max = 3/18" + "\n"
                                        + "2 - Method 2 = Sum of best 3 of 5d6. Min/Max = 3/18" + "\n"
                                        + "3 - Method 3 = Sum of best 3 of 5d6 plus 1d3. Min/Max = 4/21" + "\n");

                        int choiceNum = Integer.parseInt(menu_2);
                        Character charc = new Character();

                        String Char_type = JOptionPane
                                .showInputDialog("1-Lawful" + "\n" + "2-Neutral" + "\n" + "3-Chaotic");
                        String Char_type_2 = JOptionPane.showInputDialog("1-Good" + "\n" + "2-Evil");
                        String Char_race = JOptionPane.showInputDialog(
                                "1-Human" + "\n" + "2-Elf" + "\n" + "3-Dwarf" + "\n" + "4-Gnome" + "\n" + "5-Halfling");
                        charc.createCharacter(choiceNum, name, gender, Integer.valueOf(Char_race), Char_type,
                                Char_type_2);
                        String agree = JOptionPane.showInputDialog("Are you satisfied with scores?\n1- Yes \n2- No");
                        int choiceAgree = Integer.parseInt(agree);
                        option++;
                        if (choiceAgree == 2) {
                            option = 0;
                            continue;
                        }
                    }
                    continue;

                }

            }
            if (choice == 4) {

                String name = JOptionPane.showInputDialog("Choose the file that you to display ");
                // change this like your filename
                BufferedReader br = new BufferedReader(new FileReader("lib" + name + ".txt"));
                String aLineFromFile = null;
                while ((aLineFromFile = br.readLine()) != null) {
                    JOptionPane.showMessageDialog(null, aLineFromFile);
                }
                br.close();

            }
            if (choice == 5) {
                Character charc = new Character();
                charc.save();
            }
            if (choice == 6) {
                Character charc = new Character();
                charc.load();
            }
            if (choice == 8) {
                {
                    String name = JOptionPane.showInputDialog("Please insert your character name.");
                    String gender = JOptionPane.showInputDialog("Please select character gender(M or F).");

                    int option = 0;
                    while (option == 0) {
                        String menu_2 = JOptionPane
                                .showInputDialog("Please select one of this method for assigning ability scores" + "\n"
                                        + "1 - Method 1 = Sum of 3d6. Min/Max = 3/18" + "\n"
                                        + "2 - Method 2 = Sum of best 3 of 5d6. Min/Max = 3/18" + "\n"
                                        + "3 - Method 3 = Sum of best 3 of 5d6 plus 1d3. Min/Max = 4/21" + "\n");

                        int choiceNum = Integer.parseInt(menu_2);
                        Character_race charc = new Character_race();

                        String Char_race = JOptionPane.showInputDialog(
                                "1-Human" + "\n" + "2-Elf" + "\n" + "3-Dwarf" + "\n" + "4-Gnome" + "\n" + "5-Halfling");
                        charc.createCharacter(choiceNum, name, gender, Integer.valueOf(Char_race));
                        String agree = JOptionPane.showInputDialog("Are you satisfied with scores?\n1- Yes \n2- No");
                        int choiceAgree = Integer.parseInt(agree);
                        option++;
                        if (choiceAgree == 2) {
                            option = 0;
                            continue;
                        }
                    }
                    continue;

                }
            }

        }

    }

}
