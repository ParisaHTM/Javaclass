
package cpsc5000.javadoc;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Random;
import java.util.ArrayList;
import java.util.Scanner;

/**
 *
 * @author JavaDoc Group
 */
public class Character_race {
    private int choice;
    public static int sum;
    private String nameChar;
    private String gender;
    private String Char_type_2;
    private String Char_type;
    private int strength;
    private int dexterity;
    private int constitution;
    private int Intelligence;
    private int wisdom;
    private int charisma;
    public static ArrayList<Double> human;
    public static ArrayList<Double> Elf;
    public static ArrayList<Double> Dwarf;
    public static ArrayList<Double> Gnome;
    public static ArrayList<Double> Halfling;

    public Character_race() {

    }

    public int chooseMethod1() {
        Random rand = new Random();
        sum = 0;
        for (int a = 0; a < 4; a++) {

            int i = rand.nextInt(5) + 1;
            // System.out.println(i);
            sum = sum + i;
            if (sum < 3 & sum > 18) {
                continue;
            }

        }

        return sum;
    }

    public int chooseMethod2() {
        sum = 0;
        do {

            Random rand = new Random();

            int[] number = new int[5];

            for (int b = 0; b < 5; b++) {
                int i = rand.nextInt(5) + 1;

                number[b] = i;
            }

            for (int c = 0; c < 4; c++) {
                int max_num = number[0];
                int e = 0;
                for (int d = 0; d < number.length; d++) {
                    if (number[d] > max_num) {
                        max_num = number[d];
                        e = d;
                    }
                }
                number[e] = 0;
                sum = sum + max_num;
            }

        } while (sum >= 3 && sum <= 18);

        if (sum >= 3 && sum <= 18) {
            return sum;
        } else {
            return sum - 7;
        }

    }

    public int chooseMethod3() {
        sum = 0;
        do {

            Random rand = new Random();
            int[] number = new int[5];

            for (int b = 0; b < 5; b++) {
                int i = rand.nextInt(5) + 1;

                number[b] = i;
            }

            for (int c = 0; c < 4; c++) {

                int max_num = number[0];
                int e = 0;
                for (int d = 0; d < number.length; d++) {
                    if (number[d] > max_num) {
                        max_num = number[d];
                        e = d;
                    }
                }
                number[e] = 0;

                // maxArray[c] = max_num;
                Random plus = new Random();
                int[] plusNumber = new int[3];
                for (int f = 0; f < 3; f++) {
                    int j = plus.nextInt(3) + 1;
                    plusNumber[f] = j;
                }

                int maxPlus = plusNumber[0];
                for (int d = 0; d < 3; d++) {

                    if (plusNumber[d] > max_num) {
                        maxPlus = plusNumber[d];
                    }
                }

                sum = sum + max_num + maxPlus;
            }

        } while (sum >= 3 && sum <= 21);

        if (sum >= 3 && sum <= 21)
            return sum;
        else
            return sum - 20;
    }

    public int Human_age() {
        Random age = new Random();
        int a = age.nextInt(15);
        return a + 15;
    }

    public int Elf_age() {
        Random age = new Random();
        int a = age.nextInt(100);
        return a + 80;
    }

    public int Dwarf_age() {
        Random age = new Random();
        int a = age.nextInt(30);
        return a + 40;
    }

    public int Gnome_age() {
        Random age = new Random();
        int a = age.nextInt(30);
        return a + 30;
    }

    public int Halfling_age() {
        Random age = new Random();
        int a = age.nextInt(20);
        return a + 30;
    }

    public int Human_Weight_M() {
        Random age = new Random();
        int a = age.nextInt(170);
        return a + 90;
    }

    public int Elf_Weight_M() {
        Random age = new Random();
        int a = age.nextInt(60);
        return a + 70;
    }

    public int Dwarf_Weight_M() {
        Random age = new Random();
        int a = age.nextInt(80);
        return a + 150;
    }

    public int Gnome_Weight_M() {
        Random age = new Random();
        int a = age.nextInt(20);
        return a + 40;
    }

    public int Halfling_Weight_M() {
        Random age = new Random();
        int a = age.nextInt(25);
        return a + 30;
    }

    public int Human_Weight_F() {
        Random age = new Random();
        int a = age.nextInt(125);
        return a + 75;
    }

    public int Elf_Weight_F() {
        Random age = new Random();
        int a = age.nextInt(30);
        return a + 65;
    }

    public int Dwarf_Weight_F() {
        Random age = new Random();
        int a = age.nextInt(55);
        return a + 125;
    }

    public int Gnome_Weight_F() {
        Random age = new Random();
        int a = age.nextInt(20);
        return a + 35;
    }

    public int Halfling_Weight_F() {
        Random age = new Random();
        int a = age.nextInt(25);
        return a + 45;
    }

    public double Human_Height_M() {
        Random age = new Random();
        double a = age.nextDouble(2.9);
        return a + 4.6;
    }

    public double Elf_Height_M() {
        Random age = new Random();
        double a = age.nextDouble(1.6);
        return a + 4;
    }

    public double Dwarf_Height_M() {
        Random age = new Random();
        double a = age.nextDouble(0.10);
        return a + 4;
    }

    public double Gnome_Height_M() {
        Random age = new Random();
        double a = age.nextDouble(0.9);
        return a + 2.6;
    }

    public double Halfling_Height_M() {
        Random age = new Random();
        double a = age.nextDouble(1.1);
        return a + 3.2;
    }

    public double Human_Height_F() {
        Random age = new Random();
        double a = age.nextDouble(2.3);
        return a + 4.4;
    }

    public double Elf_Height_F() {
        Random age = new Random();
        double a = age.nextDouble(1.6);
        return a + 3.8;
    }

    public double Dwarf_Height_F() {
        Random age = new Random();
        double a = age.nextDouble(0.9);
        return a + 3.8;
    }

    public double Gnome_Height_F() {
        Random age = new Random();
        double a = age.nextDouble(0.9);
        return a + 2.4;
    }

    public double Halfling_Height_F() {
        Random age = new Random();
        double a = age.nextDouble(1.99);
        return a + 2.11;
    }

    public void createCharacter(int choice, String nameChar, String gender, int race) throws FileNotFoundException {
        this.nameChar = nameChar;
        this.gender = gender;
        this.choice = choice;

        if (choice == 1) {
            this.strength = chooseMethod1();
            this.dexterity = chooseMethod1();
            this.constitution = chooseMethod1();
            this.Intelligence = chooseMethod1();
            this.wisdom = chooseMethod1();
            this.charisma = chooseMethod1();
        }
        if (choice == 2) {
            this.strength = chooseMethod2();
            this.dexterity = chooseMethod2();
            this.constitution = chooseMethod2();
            this.Intelligence = chooseMethod2();
            this.wisdom = chooseMethod2();
            this.charisma = chooseMethod2();
        }

        if (choice == 3) {

            this.strength = chooseMethod3();
            this.dexterity = chooseMethod3();
            this.constitution = chooseMethod3();
            this.Intelligence = chooseMethod3();
            this.wisdom = chooseMethod3();
            this.charisma = chooseMethod3();

        }

        if (gender.equals("M")) {
            if (race == 1) {
                human = new ArrayList();
                human.add(Double.valueOf(Human_age()));
                human.add(Double.valueOf(Human_Weight_M()));
                human.add(Human_Height_M());
                System.out.println(human);
            }

            if (race == 2) {
                Elf = new ArrayList();
                dexterity = dexterity + 2;
                Intelligence = Intelligence + 2;
                constitution = constitution - 2;
                Elf.add(Double.valueOf(Elf_age()));
                Elf.add(Double.valueOf(Elf_Weight_M()));
                Elf.add(Elf_Height_M());
                System.out.println(Elf);
            }
            if (race == 3) {
                Dwarf = new ArrayList();
                strength = strength + 2;
                constitution = constitution + 2;
                charisma = charisma - 2;
                Dwarf.add(Double.valueOf(Dwarf_age()));
                Dwarf.add(Double.valueOf(Dwarf_Weight_M()));
                Dwarf.add(Dwarf_Height_M());
                System.out.println(Dwarf);
            }
            if (race == 4) {
                Gnome = new ArrayList();
                dexterity = dexterity + 2;
                constitution = constitution + 2;
                strength = strength - 2;
                Gnome.add(Double.valueOf(Gnome_age()));
                Gnome.add(Double.valueOf(Gnome_Weight_M()));
                Gnome.add(Gnome_Height_M());
                System.out.println(Gnome);
            }
            if (race == 5) {
                Halfling = new ArrayList();
                dexterity = dexterity + 2;
                wisdom = wisdom + 2;
                strength = strength - 2;
                Halfling.add(Double.valueOf(Halfling_age()));
                Halfling.add(Double.valueOf(Halfling_Weight_M()));
                Halfling.add(Halfling_Height_M());
                System.out.println(Halfling);
            }
        } else if (gender.equals("F")) {
            if (race == 1) {
                human = new ArrayList();
                human.add(Double.valueOf(Human_age()));
                human.add(Double.valueOf(Human_Weight_F()));
                human.add(Human_Height_F());
                System.out.println(human);
            }

            if (race == 2) {
                Elf = new ArrayList();
                dexterity = dexterity + 2;
                Intelligence = Intelligence + 2;
                constitution = constitution - 2;
                Elf.add(Double.valueOf(Elf_age()));
                Elf.add(Double.valueOf(Elf_Weight_F()));
                Elf.add(Elf_Height_F());
                System.out.println(Elf);
            }
            if (race == 3) {
                Dwarf = new ArrayList();
                strength = strength + 2;
                constitution = constitution + 2;
                charisma = charisma - 2;
                Dwarf.add(Double.valueOf(Dwarf_age()));
                Dwarf.add(Double.valueOf(Dwarf_Weight_F()));
                Dwarf.add(Dwarf_Height_F());
                System.out.println(Dwarf);
            }
            if (race == 4) {
                Gnome = new ArrayList();
                dexterity = dexterity + 2;
                constitution = constitution + 2;
                strength = strength - 2;
                Gnome.add(Double.valueOf(Gnome_age()));
                Gnome.add(Double.valueOf(Gnome_Weight_F()));
                Gnome.add(Gnome_Height_F());
                System.out.println(Gnome);
            }
            if (race == 5) {
                Halfling = new ArrayList();
                dexterity = dexterity + 2;
                wisdom = wisdom + 2;
                strength = strength - 2;
                Halfling.add(Double.valueOf(Halfling_age()));
                Halfling.add(Double.valueOf(Halfling_Weight_F()));
                Halfling.add(Halfling_Height_F());

                System.out.println(Halfling);
            }

        }
        System.out.print("Strength = " + strength + "\n" + "Dexterity = " + dexterity + "\n" +
                "Constitution = " + constitution + "\n" + "Intelligence = " + Intelligence + "\n" +
                "Wisdom = " + wisdom + "\n" + "Charisma = " + charisma + "\n");

        // Path
        PrintWriter outputFile = new PrintWriter("/Users/Nafiseh/Desktop/cpsc5000/a/lib" + nameChar + ".txt");

        outputFile.write("Strength = " + strength + "\n" + "Dexterity = " + dexterity + "\n" +
                "Constitution = " + constitution + "\n" + "Intelligence = " + Intelligence + "\n" +
                "Wisdom = " + wisdom + "\n" + "Charisma = " + charisma + "\n");

        switch (Integer.valueOf(race)) {
            case 1:
                for (double str : human) {
                    outputFile.write(str + System.lineSeparator());
                }
                break;

            case 2:
                for (double str : Elf) {
                    outputFile.write(str + System.lineSeparator());
                }
                break;

            case 3:
                for (double str : Dwarf) {
                    outputFile.write(str + System.lineSeparator());
                }
                break;
            case 4:
                for (double str : Gnome) {
                    outputFile.write(str + System.lineSeparator());
                }
            case 5:
                for (double str : Halfling) {
                    outputFile.write(str + System.lineSeparator());
                }
                break;

            default:
                break;

        }

        outputFile.close();

    }

    public ArrayList<String> displayScores(String nameChar) throws FileNotFoundException {

        ArrayList<String> list;
        try (
                Scanner s = new Scanner(new File("/Users/Nafiseh/Desktop/cpsc5000/javadoc" + nameChar + ".txt"))) {
            list = new ArrayList<>();
            while (s.hasNext()) {
                list.add(s.next());
            }
        }
        return list;
        // System.out.println(list);

    }

}
