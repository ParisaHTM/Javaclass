
package cpsc5000.javadoc;

import javax.swing.JOptionPane;

public class Character
{
    
 //   private String nameChar; //dis by Ali 
 //   private String gender;  //dis by Ali 
 //   private String race;   //dis by Ali 
    private int strength;
    private int dexterity;
    private int constitution;
    private int intelligence;
    private int wisdom;
    private int charisma;
    private String choice;    //add by Ali
    
    /* dis by Ali
    public void createCharacter(final int choice, final String nameChar, final String gender) {
        this.nameChar = nameChar;
        this.gender = gender;
        this.race = this.race;
*/
    public void createCharacter( final int ch) {
        final Methods meth = new Methods();
        final Score sco = new Score();
        int[] methScore = new int[6];
        if (ch == 1) {
            methScore = meth.chooseMethod1();
        }
        if (ch == 2) {
            methScore = meth.chooseMethod2();
        }
        if (ch == 3) {
            methScore = meth.chooseMethod3();
        }
        final int[] scoreAbility = sco.getScore(methScore);
        this.strength = scoreAbility[0];
        this.dexterity = scoreAbility[1];
        this.constitution = scoreAbility[2];
        this.intelligence = scoreAbility[3];
        this.wisdom = scoreAbility[4];
        this.charisma = scoreAbility[5];
       System.out.print(invokedynamic(makeConcatWithConstants->(IIIIII)Ljava/lang/String, this.strength, this.dexterity, this.constitution, this.intelligence, this.wisdom, this.charisma));   //Edited by Ali
    }
    public void setchoise() {
        this.choice = JOptionPane.showInputDialog("Please select one of this method for assigning ability scores\n1 - Method 1 = Sum of 3d6. Min/Max = 3/18\n2 - Method 2 = Sum of best 3 of 5d6. Min/Max = 3/18\n3 - Method 3 = Sum of best 3 of 5d6 plus 1d3. Min/Max = 4/21\n");
    }
    public String getchoice() {
        return this.choice;
    }
    public void setstr(int ab) {
        this.strength=ab;
    }
    public int getstr() {
        return this.strength;
    }
 public void setdex(int ab) {
        this.dexterity=ab;
    }
    public int getdex() {
        return this.dexterity;
    }
 public void setcon(int ab) {
        this.constitution=ab;
    }
    public int getcon() {
        return this.constitution;
    }
 public void setint(int ab) {
        this.intelligence=ab;
    }
    public int getint() {
        return this.intelligence;
    }
 public void setwis(int ab) {
        this.wisdom=ab;
    }
    public int getwis() {
        return this.wisdom;
    }
 public void setchar(int ab) {
        this.charisma=ab;
    }
    public int getchar() {
        return this.charisma;
    }
    
    
}
