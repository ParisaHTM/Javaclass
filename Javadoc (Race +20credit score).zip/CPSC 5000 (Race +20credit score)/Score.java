
package cpsc5000.javadoc;

import java.util.Scanner;

public class Score
{
    String[] ability;
    
    public Score() {
        this.ability = new String[] { "strength", "dexterity", "constitution", "intelligence", "wisdom", "charisma" };
    }
    
    public int[] getScore(final int[] methodScore) {
        final Scanner input = new Scanner(System.in);
        final int[] methodScoreAbility = new int[6];
        for (int ii = 0; ii < this.ability.length; ++ii) {
            String prompt = new String();
            for (int jj = 0; jj < methodScore.length; ++jj) {
                if (methodScore[jj] != 0) {
                    prompt = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;I)Ljava/lang/String;, prompt, Integer.toString(jj + 1), methodScore[jj]);
                }
            }
            System.out.print(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, this.ability[ii], prompt));
            final int scoreIndex = input.nextInt();
            methodScoreAbility[ii] = methodScore[scoreIndex - 1];
            methodScore[scoreIndex - 1] = 0;
        }
        return methodScoreAbility;
    }
}
