
package cpsc5000.javadoc;

import java.io.FileNotFoundException;
import java.awt.Component;
import java.io.File;
import javax.swing.JOptionPane;
import java.util.Scanner;

public class Javadoc
{
    public static void main(final String[] args) throws FileNotFoundException {
        final Scanner input = new Scanner(System.in);
        final User user = new User();
        final Load load = new Load();
        final String path = "/Users/parisa/NetBeansProjects/javadoc/";
        int choice = 0;
        /*
        while (choice != 7) {
            final String menu = JOptionPane.showInputDialog("Please select the number of your option:\n1. Create user account\n2. Load user account\n3. Create character\n4. Display character\n5. Save character\n6. Load character\n7. Exit");
         */ //dis by Ali
         while (choice != 8) {
            final String menu = JOptionPane.showInputDialog("Please select the number of your option:\n1. Create user account\n2. Load user account\n3. Create character\n4. Display character\n5. Save character\n6. Load character\n7.Edit character\n8. Exit");         
           choice = Integer.parseInt(menu);
            if (choice == 1) {
                user.setUsername();
                final String usernameUser = user.getUserName();
                final File userFile = new File(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, path, usernameUser));
                if (userFile.exists()) {
                    JOptionPane.showMessageDialog(null, "This user name already exists. Please choose another user name or load your username");
                }
                else {
                    user.setPassword();
                    user.setEmailAddress();
                    user.getPassword();
                    user.getEmailAddress();
                    user.saveUser(path);
                }
            }
            else if (choice == 2) {
                load.setUsernameLoad();
                final String username = load.getUsernameLoad();
                final File loadUserPath = new File(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, path, username));
                if (loadUserPath.exists()) {
                    load.setPasswordLoad();
                    final String password = load.getPasswordLoad();
                    final Scanner id = user.loadUser(username, path);
                    id.nextLine();
                    final String passwordId = id.nextLine();
                    final String emailAddressId = id.nextLine();
                    System.out.println(emailAddressId);
                    if (password.equals(passwordId)) {
                        continue;
                    }
                    final String email = JOptionPane.showInputDialog("Your password is wrong.Please enter your email address:");
                    if (email.equals(emailAddressId)) {
                        JOptionPane.showMessageDialog((Component)null, invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, passwordId));
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "Your email address is wrong. Please try again!");
                    }
                }
                else {
                    JOptionPane.showMessageDialog(null, "Your user account does not existed. Please create your user name first.");
                }
            }
            else if (choice == 3) {
                System.out.println("*****");
                final String username = load.getUsernameLoad();
                final String password2 = load.getPasswordLoad();
                final File loadUserPath2 = new File(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, path, username));
                System.out.println(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, path, username));
                if (loadUserPath2.exists()) {
                    final Scanner id = user.loadUser(username, path);
                    id.nextLine();
                    final String passwordId = id.nextLine();
                    System.out.println(passwordId);
                    System.out.println(password2);
                    if (password2.equals(passwordId)) {
                //        final String name = JOptionPane.showInputDialog("Please insert your character name.");        //dis by Ali
                //        final String gender = JOptionPane.showInputDialog("Please select character gender(M or F).");     //dis by Ali
                          final Character charc = new Character();
                            final Race race=new Race();
                            race.setnamaChar();
                            race.setgender();
                            charc.setchoise();
                            final int choiceNum = Integer.parseInt(charc.getchoice());
                            charc.createCharacter(choiceNum);
                            race.setrace();
                            final String agree = JOptionPane.showInputDialog("Are you satisfied with scores?\n1- Yes \n2- No");
                            final int choiceAgree = Integer.parseInt(agree);  
                            for (int option = 0; option == 0; option = 0) {
                //            final String menu_2 = JOptionPane.showInputDialog("Please select one of this method for assigning ability scores\n1 - Method 1 = Sum of 3d6. Min/Max = 3/18\n2 - Method 2 = Sum of best 3 of 5d6. Min/Max = 3/18\n3 - Method 3 = Sum of best 3 of 5d6 plus 1d3. Min/Max = 4/21\n");       //dis by Ali
                //            final String Race = JOptionPane.showInputDialog("Please select character Race :\n1 - Human\n2 - Elf\n3 - Dwarf\n4 - Gnome\n5 - Halfling\n");                  //dis by Ali
                            
                            final String alignments = JOptionPane.showInputDialog("Do you want to choose an alignment for your character?\n1- Yes \n2- No");
                            final int choiceAlignment = Integer.parseInt(alignments);
                            if (choiceAlignment == 1) {
                                JOptionPane.showInputDialog("Please select character's alignment :\n1 - Lawful Good\n2 - Lawful Evil\n3 - Neutral Good\n4 - Neutral Evil\n5 - Chaotic Good\n6 - Chaotic Evil\n");
                            }
                            /*
                            final int choiceNum = Integer.parseInt(menu_2);
                            final Character charc = new Character();
                            charc.createCharacter(choiceNum, name, gender);
                            final String agree = JOptionPane.showInputDialog("Are you satisfied with scores?\n1- Yes \n2- No");
                            final int choiceAgree = Integer.parseInt(agree);
                            */ // dis by Ali
                            ++option;
                            if (choiceAgree == 2) {}
                        }
                    }
                    else {
                        JOptionPane.showMessageDialog(null, "Your password is not correct, please try again!");
                    }
                }
                else {
                    JOptionPane.showMessageDialog(null, "First, you have to log in!");
                }
            }
       //     else if (choice == 4) {}  // dis by Ali
         else if (choice == 8) {
            	System.out.println("*****");
                final String username = load.getUsernameLoad();
                final String password2 = load.getPasswordLoad();
                final File loadUserPath2 = new File(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, path, username));
                System.out.println(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, path, username));
                if (loadUserPath2.exists()) {
                    final Scanner id = user.loadUser(username, path);
                    id.nextLine();
                    final String passwordId = id.nextLine();
                    System.out.println(passwordId);
                    System.out.println(password2);
                    if (password2.equals(passwordId)) {
                    	final Character charc = new Character();
                    	final Race race=new Race();
                    	 JOptionPane.showMessageDialog(null, "Edit Character\n");
                    	 JOptionPane.showMessageDialog(null, "Edit Name :");
                    	 race.setnamaChar();
                    	 JOptionPane.showMessageDialog(null, "Edit gender :\n");
                    	 race.setgender();
                    	 JOptionPane.showMessageDialog(null, "Edit ability Score\n");
                    	 charc.setchoise();
                    	 JOptionPane.showMessageDialog(null, "Edit Race :\n");
                    	 race.setrace();
                         
                         
                         
                         
                     }
                    else {
                        JOptionPane.showMessageDialog(null, "Your password is not correct, please try again!");
                    }
                }
                else {
                    JOptionPane.showMessageDialog(null, "First, you have to log in!");
                }
                    }
            }
        }
    }    
                                                 
