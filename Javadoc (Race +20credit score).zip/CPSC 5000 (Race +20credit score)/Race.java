package cpsc5000;
import javax.swing.JOptionPane;
public class Race {
	private String nameChar;
    private String gender;
    private String race;
    private int[] absco = new int[6];
    Character charc =new Character();
    public void setnamaChar() {
        this.nameChar = JOptionPane.showInputDialog("Please insert your character name.");
    }
        public String getnameChar() {
        return this.nameChar;
    }
    public void setgender() {
        this.gender = JOptionPane.showInputDialog("Please select character gender(M or F).");
    }
    public String getgender() {
        return this.gender;
    }
    public void setrace() {
        this.race = JOptionPane.showInputDialog("Please select character Race :\n1 - Human\n2 - Elf\n3 - Dwarf\n4 - Gnome\n5 - Halfling\n");
        int raceab=Integer.parseInt(race);
        this.absco = new int[]{charc.getstr(), charc.getdex(), charc.getcon(),
                charc.getint(), charc.getwis(), charc.getchar()}; 
        
        if(raceab==2) {
        	   
        	charc.setdex( charc.getdex()+2);
        	charc.setint( charc.getint()+2);
        	charc.setcon( charc.getcon()-2);
        	
        }
        if(raceab==3) {
        	
        	charc.setstr( charc.getstr()+2);
        	charc.setcon( charc.getcon()+2);
        	charc.setchar( charc.getchar()-2);
        }
        if(raceab==4) {
        	
        	charc.setdex( charc.getdex()+2);
        	charc.setcon( charc.getcon()+2);
        	charc.setstr( charc.getstr()-2);
        	
        }
        if(raceab==5) {
        	
        	charc.setdex( charc.getdex()+2);
        	charc.setwis( charc.getwis()+2);
        	charc.setstr( charc.getstr()-2);
        	
        }
    }
    public String getrace() {
    	JOptionPane.showMessageDialog(null,"Your race is = "+ this.race + "\n" +
                "Strength = "+ absco[1]+ "\n"+ "Dexterity = "+ absco[2] +"\n"+
                "Constitution = "+ absco[3]+"\n"+"Intelligence = " + absco[4] + "\n"+
                "Wisdom = "+ absco[5]+"\n"+ "Charisma = "+ absco[6]+ "\n");
        return this.race;
    }
}
