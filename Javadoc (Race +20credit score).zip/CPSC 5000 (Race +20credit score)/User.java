package cpsc5000.javadoc;

import javax.swing.JOptionPane;
import java.io.File;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class User
{
    private String username;
    private String password;
    private String emailAddress;
    private String gender;
    private String line;
    
    public User() {
        this.line = null;
        this.username = null;
        this.password = null;
        this.emailAddress = null;
    }
    
    public void saveUser(final String path) throws FileNotFoundException {
        final PrintWriter outputFile = new PrintWriter(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, path, this.username));
        outputFile.write(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.username));
        outputFile.write(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.password));
        outputFile.write(invokedynamic(makeConcatWithConstants:(Ljava/lang/String;)Ljava/lang/String;, this.emailAddress));
        outputFile.close();
    }
    
    public Scanner loadUser(final String username, final String path) throws FileNotFoundException {
        final String inFile = invokedynamic(makeConcatWithConstants:(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;, path, username);
        final File inputFile = new File(inFile);
        final Scanner inputRead = new Scanner(inputFile);
        return inputRead;
    }
    
    public void setUsername() {
        this.username = JOptionPane.showInputDialog("Please enter your user name.");
    }
    
    public void setPassword() {
        this.password = JOptionPane.showInputDialog("Please, enter your password.");
    }
    
    public void setEmailAddress() {
        this.emailAddress = JOptionPane.showInputDialog("Please enter your email address.");
    }
    
    public String getUserName() {
        return this.username;
    }
    
    public String getPassword() {
        return this.password;
    }
    
    public String getEmailAddress() {
        return this.emailAddress;
    }
}
