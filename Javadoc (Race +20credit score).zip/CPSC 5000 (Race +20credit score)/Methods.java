
package cpsc5000.javadoc;

import java.util.Random;

public class Methods
{
    int[] score;
    
    public Methods() {
        this.score = new int[6];
    }
    
    public int[] chooseMethod1() {
        final int[] score = new int[6];
        for (int x = 0; x < 6; ++x) {
            int sum = 0;
            final Random rand = new Random();
            for (int a = 0; a < 4; ++a) {
                final int i = rand.nextInt(6) + 1;
                sum += i;
                if (sum < 3 || sum > 18) {
                    sum = 0;
                }
                else if (sum >= 3 && sum <= 18) {
                    score[x] = sum;
                }
            }
            System.out.println(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, x, score[x]));
        }
        return score;
    }
    
    public int[] chooseMethod2() {
        final int[] score = new int[6];
        int sum = 0;
        while (sum == 0) {
            for (int x = 0; x < 6; ++x) {
                for (int s = 0; s < 6; ++s) {
                    sum = 0;
                    final Random rand = new Random();
                    final int[] number = new int[5];
                    for (int b = 0; b < 5; ++b) {
                        final int i = rand.nextInt(6) + 1;
                        number[b] = i;
                    }
                    for (int c = 0; c < 4; ++c) {
                        int max_num = number[0];
                        int e = 0;
                        for (int d = 0; d < number.length; ++d) {
                            if (number[d] > max_num) {
                                max_num = number[d];
                                e = d;
                            }
                        }
                        number[e] = 0;
                        sum += max_num;
                    }
                }
                if (sum < 3 || sum > 18) {
                    sum = 0;
                }
                else {
                    if (sum >= 3 && sum <= 18) {
                        score[x] = sum;
                    }
                    System.out.println(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, x, score[x]));
                }
            }
        }
        return score;
    }
    
    public int[] chooseMethod3() {
        int sum = 0;
        final int[] score = new int[6];
        while (sum == 0) {
            for (int x = 0; x < 6; ++x) {
                for (int s = 0; s < 6; ++s) {
                    sum = 0;
                    final Random rand = new Random();
                    final int[] number = new int[5];
                    for (int b = 0; b < 5; ++b) {
                        final int i = rand.nextInt(6) + 1;
                        number[b] = i;
                    }
                    for (int c = 0; c < 4; ++c) {
                        int max_num = number[0];
                        int e = 0;
                        for (int d = 0; d < number.length; ++d) {
                            if (number[d] > max_num) {
                                max_num = number[d];
                                e = d;
                            }
                        }
                        number[e] = 0;
                        final Random plus = new Random();
                        final int[] plusNumber = new int[3];
                        for (int f = 0; f < 3; ++f) {
                            final int j = plus.nextInt(3) + 1;
                            plusNumber[f] = j;
                        }
                        int maxPlus = plusNumber[0];
                        for (int d2 = 1; d2 < plusNumber.length; ++d2) {
                            if (plusNumber[d2] > max_num) {
                                maxPlus = plusNumber[d2];
                            }
                        }
                        sum = sum + max_num + maxPlus;
                    }
                }
                if (sum < 3 || sum > 18) {
                    sum = 0;
                }
                else {
                    if (sum >= 3 && sum <= 18) {
                        score[x] = sum;
                    }
                    System.out.println(invokedynamic(makeConcatWithConstants:(II)Ljava/lang/String;, x, score[x]));
                }
            }
        }
        return score;
    }
}
