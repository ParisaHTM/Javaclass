
package cpsc5000.javadoc;

import javax.swing.JOptionPane;

public class Load
{
    private String usernameLoad;
    private String passwordLoad;
    
    public Load() {
        this.usernameLoad = "NotTheSame";
        this.passwordLoad = "NotTheSame";
    }
    
    public void setUsernameLoad() {
        this.usernameLoad = JOptionPane.showInputDialog("Please enter your user name.");
    }
    
    public String getUsernameLoad() {
        return this.usernameLoad;
    }
    
    public void setPasswordLoad() {
        this.passwordLoad = JOptionPane.showInputDialog("Please enter your password.");
    }
    
    public String getPasswordLoad() {
        return this.passwordLoad;
    }
}
