package Menu;

import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class Character {

    private String Race;
    private String nameChar;
    private String gender;
    private String Alignment;
    private int strength;
    private int dexterity;
    private int constitution;
    private int Intelligence;
    private int wisdom;
    private int charisma;
    private int race;
    private int age;
    private int Weight;
    private double Height;

    public Character() {

    }

    public void set_power(String choose_m) {
        //set abilities score depend on choosen method 
        Method_1 me1 = new Method_1();
        Method_2 me2 = new Method_2();
        Method_3 me3 = new Method_3();
        switch (Integer.parseInt(choose_m)) {
            case 1:
                this.strength = me1.chooseMethod1();
                this.dexterity = me1.chooseMethod1();
                this.constitution = me1.chooseMethod1();
                this.Intelligence = me1.chooseMethod1();
                this.wisdom = me1.chooseMethod1();
                this.charisma = me1.chooseMethod1();
                break;
            case 2:
                this.strength = me2.chooseMethod2();
                this.dexterity = me2.chooseMethod2();
                this.constitution = me2.chooseMethod2();
                this.Intelligence = me2.chooseMethod2();
                this.wisdom = me2.chooseMethod2();
                this.charisma = me2.chooseMethod2();
                break;
            case 3:
                this.strength = me3.chooseMethod3();
                this.dexterity = me3.chooseMethod3();
                this.constitution = me3.chooseMethod3();
                this.Intelligence = me3.chooseMethod3();
                this.wisdom = me3.chooseMethod3();
                this.charisma = me3.chooseMethod3();
                break;
            default:
                break;
        }

    }

    public void set_aligment(String aligment) {
        //set alignment
        this.Alignment = aligment;
    }

    public void set_race(int race) {
        this.race = race;
        // set race of the character and changing the ability
        if (race == 1) {
            this.Race = "Human";
        }

        if (race == 2) {
            this.Race = "Elf";
            dexterity = dexterity + 2;
            Intelligence = Intelligence + 2;
            constitution = constitution - 2;

        }
        if (race == 3) {
            this.Race = "Elf";
            strength = strength + 2;
            constitution = constitution + 2;
            charisma = charisma - 2;

        }
        if (race == 4) {
            this.Race = "Dwarf";
            dexterity = dexterity + 2;
            constitution = constitution + 2;
            strength = strength - 2;

        }
        if (race == 5) {
            this.Race = "Halfling";
            dexterity = dexterity + 2;
            wisdom = wisdom + 2;
            strength = strength - 2;

        }
    }

    public void set_details(String gender) {
        //instantiating classes
        Human H = new Human();
        Elf E = new Elf();
        Dwarf D = new Dwarf();
        Gnome G = new Gnome();
        Halfling Ha = new Halfling();
        //generating age,weight,height depends of the race and gender
        switch (race) {
            case 1 -> {
                this.age = H.Human_age();
                this.Weight = H.Human_Weight(gender);
                this.Height = H.Human_Height(gender);
            }
            case 2 -> {
                this.age = E.Elf_age();
                this.Weight = E.Elf_Weight(gender);
                this.Height = E.Elf_Height(gender);
            }
            case 3 -> {

                this.age = D.Dwarf_age();
                this.Weight = D.Dwarf_Weight(gender);
                this.Height = D.Dwarf_Height(gender);
            }
            case 4 -> {
                this.age = G.Gnome_age();
                this.Weight = G.Gnome_Weight(gender);
                this.Height = G.Gnome_Height(gender);
            }

            case 5 -> {
                this.age = Ha.Halfling_age();
                this.Weight = Ha.Halfling_Weight(gender);
                this.Height = Ha.Halfling_Height(gender);
            }
        }

    }

    public void createCharacter(String nameChar, String gender) {
        
        //set the name and gender of character
        this.gender = gender;
        this.nameChar = nameChar;

    }

    public void Display() {
        
        //printing the data
        System.out.println("Character Name = " + nameChar + "\n");
        System.out.println("Character gender  = " + gender + "\n");
        System.out.println("Character strength  = " + strength + "\n");
        System.out.println("Character dexterity  = " + dexterity + "\n");
        System.out.println("Character constitution  = " + constitution + "\n");
        System.out.println("Character Intelligence  = " + Intelligence + "\n");
        System.out.println("Character wisdom  = " + wisdom + "\n");
        System.out.println("Character charisma  = " + charisma + "\n");
        System.out.println("Character Alignment  = " + Alignment + "\n");
        System.out.println("Character Race  = " + Race + "\n");
        System.out.println("Character age  = " + age + "\n");
        System.out.println("Character Weight  = " + Weight + "\n");
        System.out.println("Character Height  = " + Height + "\n");

    }

    public void save(String path) throws FileNotFoundException {
        //save data in this path
        try (PrintWriter outputFile = new PrintWriter(path + nameChar + ".txt")) {
            outputFile.write("Character Name = " + nameChar + "\n");
            outputFile.write("Character gender  = " + gender + "\n");
            outputFile.write("Character strength  = " + strength + "\n");
            outputFile.write("Character dexterity  = " + dexterity + "\n");
            outputFile.write("Character constitution  = " + constitution + "\n");
            outputFile.write("Character Intelligence  = " + Intelligence + "\n");
            outputFile.write("Character wisdom  = " + wisdom + "\n");
            outputFile.write("Character charisma  = " + charisma + "\n");
            outputFile.write("Character Alignment  = " + Alignment + "\n");
            outputFile.write("Character Race  = " + Race + "\n");
            outputFile.write("Character age  = " + age + "\n");
            outputFile.write("Character Weight  = " + Weight + "\n");
            outputFile.write("Character Height  = " + Height + "\n");
        }
    }

}
