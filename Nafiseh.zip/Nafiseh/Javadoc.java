package Menu;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

public class Javadoc {

    public static void main(String[] args) throws FileNotFoundException, IOException {
        

        String path = "/Users/Nafiseh/Documents/NetBeansProjects/test/";
        int choice = 0;
        Character charc = new Character();

        while (choice != 8) {

            String menu = JOptionPane.showInputDialog("""
                    Please select the number of your option:
                    1. Create user account
                    2. Load user account
                    3. Create character
                    4. Display character
                    5. Save character
                    6. Load character
                    7. Change race
                    8. Exit""");

            if (menu == null) {
                break;
            }
            //both of them is the same (up and down lines)
            if ("".equals(menu)) {
                break;
            }
            choice = Integer.parseInt(menu);
            // loop over menu
            if (choice == 1) {
                String userName = JOptionPane.showInputDialog("Please enter your username:");
                File userFile = new File(path + userName + ".txt");
                if (userFile.exists()) {
                    System.out.println("This username already exists! Please choose another username:");
                    continue;
                }
                String password = JOptionPane.showInputDialog("Please, enter your password:");
                String emailAddress = JOptionPane.showInputDialog("Please enter your email address:");

                User user = new User(userName, password, emailAddress);
                user.saveUser(path);

                continue;
            }

            if (choice == 2) { // load user account
                String username = JOptionPane.showInputDialog("Please enter your username:");
                System.out.println("User = " + username);
                User user = new User();
                user.loadUser(username, path);
                continue;
            }
            if (choice == 3) {
                String charName = JOptionPane.showInputDialog("Please enter your user name:");
                String gender = JOptionPane.showInputDialog("Please select character gender(M or F)?");
                String choose_m = JOptionPane.showInputDialog("""
                                                              Please select one of this method for assigning ability scores
                                                              1 - Method 1 = Sum of 3d6. Min/Max = 3/18
                                                              2 - Method 2 = Sum of best 3 of 5d6. Min/Max = 3/18
                                                              3 - Method 3 = Sum of best 3 of 5d6 plus 1d3. Min/Max = 4/21
                                                              """);

                String Char_type = JOptionPane.showInputDialog("""
                                         Lawful
                                         Neutral
                                         Chaotic""");
                String Char_type_2 = JOptionPane.showInputDialog("""
                                                                 Good
                                                                 Evil""");
                //here we set the type of alignment 
                charc.set_aligment(Char_type + " " + Char_type_2);
                String Char_race = JOptionPane.showInputDialog("""
                                                               1-Human
                                                               2-Elf
                                                               3-Dwarf
                                                               4-Gnome
                                                               5-Halfling""");
                //set the type of race
                charc.set_race(Integer.valueOf(Char_race));
                //the age,weight,height will set here
                charc.set_details(gender);
                //depend of choosen method, ability score will be generated
                charc.set_power(choose_m);
                //character name and gender will be set
                charc.createCharacter(charName, gender);
                continue;

            }
            if (choice == 4) {
                //showing the character that set befor saving
                charc.Display();
                continue;
            }
            if (choice == 5) {
                //save the character created in the path with as name of character
                charc.save(path);

            }
            if (choice == 6) {
                //choosing the name of character to display
                String name = JOptionPane.showInputDialog("Choose the file to load ");
                try ( 
                    //read the file to save     
                    BufferedReader br = new BufferedReader(new FileReader("test" + name + ".txt"))) {
                    String aLineFromFile;
                    //for reading every line of text file and printing it
                    while ((aLineFromFile = br.readLine()) != null) {
                        ///JOptionPane.showMessageDialog(null, aLineFromFile);
                        System.out.println(aLineFromFile);
                    }
                }

            }
            if (choice == 7) {
                //after create chracter you can change race 
                               
                String Char_race = JOptionPane.showInputDialog("""
                                                               1-Human
                                                               2-Elf
                                                               3-Dwarf
                                                               4-Gnome
                                                               5-Halfling""");

                charc.set_race(Integer.valueOf(Char_race));
            }
        }
    }
}
