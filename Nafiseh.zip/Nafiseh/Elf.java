package Menu;

import java.util.Random;

public class Elf {

    private String gender;

    public int Elf_age() {
        Random age = new Random();// Random age between 80_180
        int a = age.nextInt(100);
        return a + 80;
    }

    public int Elf_Weight(String gender) {// Random Weight for Elf depends on gender
        this.gender = gender;
        if (gender.equals("M")) {
            Random age = new Random();
            int a = age.nextInt(60);
            return a + 70;// Between 70-130
        } else if (gender.equals("F")) {
            Random age = new Random();
            int a = age.nextInt(35);
            return a + 65;// Between 65-100
        } else {
            System.out.println("unknown gender");
            return 0;
        }

    }

    public double Elf_Height(String gender) {// Random Height for Elf depends on gender
        this.gender = gender;
        if (gender.equals("M")) {
            Random age = new Random();
            double a = age.nextDouble(1.6);
            return a + 4;// Between 4-5.6
        } else if (gender.equals("F")) {
            Random age = new Random();
            double a = age.nextDouble(1.6);
            return a + 3.8;// Between 3.8-5.4
        } else {
            System.out.println("unknown gender");
            return 0;
        }
    }
}
