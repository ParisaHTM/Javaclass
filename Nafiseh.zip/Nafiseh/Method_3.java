package Menu;

import java.util.Random;

public class Method_3 {

    private int sum;

    public int chooseMethod3() {
        sum = 0;

        while (sum == 0) {
            for (int s = 0; s < 7; s++) {
                sum = 0;
                Random rand = new Random();
                int[] number = new int[5];


                for (int b = 0; b < 5; b++) {
                    int i = rand.nextInt(6) + 1;
                    number[b] = i;
                }

                for (int c = 0; c < 4; c++) {
                    int max_num = number[0];
                    int e = 0;
                    for (int d = 0; d < number.length; d++) {
                        if (number[d] > max_num) {
                            max_num = number[d];
                            e = d;
                        }
                    }
                    number[e] = 0;

                    // maxArray[c] = max_num;
                    Random plus = new Random();
                    int[] plusNumber = new int[3];
                    for (int f = 0; f < 3; f++) {
                        int j = plus.nextInt(3) + 1;
                        plusNumber[f] = j;
                    }

                    int maxPlus = plusNumber[0];
                    for (int d = 1; d < plusNumber.length; d++) {
                        if (plusNumber[d] > max_num) {
                            maxPlus = plusNumber[d];
                        }
                    }
                    sum = sum + max_num + maxPlus;
                    // System.out.print("sum = "+ sum + "\n");
                }
            }
            if (sum < 3 || sum > 18) {
                sum = 0;
                continue;
            }
        }
        return sum;
    }
}
