package Menu;

import java.util.Random;

public class Halfling {

    private String gender;

    public int Halfling_age() {
        Random age = new Random();// Random age between 30-50
        int a = age.nextInt(20);
        return a + 30;
    }

    public int Halfling_Weight(String gender) {// Random Weight for Halfling depends on gender
        this.gender = gender;

        if (gender.equals("M")) {
            Random age = new Random();
            int a = age.nextInt(25);
            return a + 55;// Between 55-80
        } else if (gender.equals("F")) {
            Random age = new Random();
            int a = age.nextInt(25);
            return a + 45;// Between 45-70
        } else {
            System.out.println("unknown gender");
            return 0;
        }

    }

    public double Halfling_Height(String gender) {// Random Height for Dwarf depends on gender
        this.gender = gender;

        if (gender.equals("M")) {
            Random age = new Random();
            double a = age.nextDouble(1.1);
            return a + 3.2;// Between 3.2-4.3
        } else if (gender.equals("F")) {
            Random age = new Random();
            double a = age.nextDouble(1.99);
            return a + 2.11;// Between 2.11-4.1
        } else {
            System.out.println("unknown gender");
            return 0;
        }
    }
}
