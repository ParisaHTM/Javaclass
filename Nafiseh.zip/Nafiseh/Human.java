package Menu;

import java.util.Random;

public class Human {

    private String gender;

    public int Human_age() {
        Random age = new Random();
        int a = age.nextInt(15);
        return a + 15;
    }

    public int Human_Weight(String gender) {// Random Weight for Human depends on gender
        this.gender = gender;
        if (gender.equals("M")) {
            Random age = new Random();
            int a = age.nextInt(170);
            return a + 90;// Between 90-260
        } else if (gender.equals("F")) {
            Random age = new Random();
            int a = age.nextInt(125);
            return a + 75;// Between 75-200

        } else {
            System.out.println("unknown gender");
            return 0;
        }
    }
        public double Human_Height(String gender) {// Random Height for Human depends on gender
        this.gender = gender;

        if (gender.equals("M")) {
            Random age = new Random();
            double a = age.nextDouble(2.9);
            return a + 4.6;// Between 4.6-7.5
        } else if (gender.equals("F")) {
            Random age = new Random();
            double a = age.nextDouble(2.3);
            return a + 4.4;// Between 4.4-6.7
        } else {
            System.out.println("unknown gender");
            return 0;
        }
    }
}
