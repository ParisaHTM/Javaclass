
package Menu;

import java.util.Random;

public class Method_2 {

    private int sum;

        public int chooseMethod2() {
        sum = 0;
        while (sum == 0) {
            for (int s = 0; s < 7; s++) // for abilities
            {
                sum = 0;
                Random rand = new Random();
                int[] number = new int[5]; // for choosing 5 number

                for (int b = 0; b < 5; b++) // for choosing 5 number
                {
                    int i = rand.nextInt(6) + 1;
                    number[b] = i;
                }

                for (int c = 0; c < 4; c++) // for choosing 3 of them for sum
                {
                    int max_num = number[0];
                    int e = 0;
                    for (int d = 0; d < number.length; d++) {
                        if (number[d] > max_num) {
                            max_num = number[d];
                            e = d;
                        }
                    }
                    // maxArray[c] = max_num;
                    number[e] = 0;
                    sum = sum + max_num;
                    // System.out.print("sum = "+ sum + "\n");

                }
            }
            if (sum < 3 || sum > 18) {
                sum = 0;
                continue;
            }
        }
        return sum;
    }
}
