package Menu;

import java.util.Random;

public class Dwarf {

    private String gender;
    
    public int Dwarf_age() {
        Random age = new Random();// Random age between 40-70
        int a = age.nextInt(30);
        return a + 40;
    }

    public int Dwarf_Weight(String gender) {// Random Weight for Dwarf depends on gender
        this.gender = gender;

        if (gender.equals("M")) {
            Random age = new Random();
            int a = age.nextInt(80);
            return a + 150;// Between 150-230
        } else if (gender.equals("F")) {
            Random age = new Random();
            int a = age.nextInt(55);
            return a + 125;// Between 125-180
        } else {
            System.out.println("unknown gender");
            return 0;
        }

    }

    public double Dwarf_Height(String gender) {// Random Height for Dwarf depends on gender
        this.gender = gender;

        if (gender.equals("M")) {
            Random age = new Random();
            double a = age.nextDouble(0.10);
            return a + 4;// Between 4-4.10
        } else if (gender.equals("F")) {
            Random age = new Random();
            double a = age.nextDouble(0.9);
            return a + 3.8;// Between 3.8-4.7
        } else {
            System.out.println("unknown gender");
            return 0;
        }
    }
}
