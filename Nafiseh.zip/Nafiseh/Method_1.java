
package Menu;

import java.util.Random;


public class Method_1 {

    private int sum;

    public int chooseMethod1() {
        sum = 0;
        Random rand = new Random();
        for (int a = 0; a < 4; a++) {
            int i = rand.nextInt(6) + 1;
            sum = sum + i;
            if (sum < 3 || sum > 18) {
                continue;
            }
        }

        return sum;
    }
}
