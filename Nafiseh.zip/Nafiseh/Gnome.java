package Menu;

import java.util.Random;

public class Gnome {

    private String gender;

    public int Gnome_age() {
        Random age = new Random();// Random age between 30-60
        int a = age.nextInt(30);
        return a + 30;
    }

    public int Gnome_Weight(String gender) {// Random Weight for Gnome depends on gender
        this.gender = gender;

        if (gender.equals("M")) {
            Random age = new Random();
            int a = age.nextInt(20);
            return a + 40;// Between 40-60
        } else if (gender.equals("F")) {
            Random age = new Random();
            int a = age.nextInt(55);
            return a + 35;// Between 35-55
        } else {
            System.out.println("unknown gender");
            return 0;
        }

    }

    public double Gnome_Height(String gender) {// Random Height for Dwarf depends on gender
        this.gender = gender;
        if (gender.equals("M")) {
            Random age = new Random();
            double a = age.nextDouble(0.9);
            return a + 2.6;// Between 2.6-3.5
        } else if (gender.equals("F")) {
            Random age = new Random();
            double a = age.nextDouble(0.9);
            return a + 2.4;// Between 2.4-3.3
        } else {
            System.out.println("unknown gender");
            return 0;
        }
    }
}
