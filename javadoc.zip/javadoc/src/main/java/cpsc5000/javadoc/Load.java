/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cpsc5000.javadoc;

import javax.swing.JOptionPane;

/**
 *
 * @author parisa
 */
public class Load {
    
    private String usernameLoad;
    private String passwordLoad;
    
    public Load(){
        this.usernameLoad = "NotTheSame";
        this.passwordLoad = "NotTheSame";
    }
    
    public void setUsernameLoad(){
        this.usernameLoad = JOptionPane.showInputDialog("Please enter your user name.");
    }
    
    public String getUsernameLoad(){
        return this.usernameLoad;
    }
    
    public void setPasswordLoad(){
        this.passwordLoad = JOptionPane.showInputDialog("Please enter your password.");
    }
    
    public String getPasswordLoad(){
        return this.passwordLoad;
    }
}
