/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cpsc5000.javadoc;
import java.util.Random;

/**
 *
 * @author parisa
 */
public class Methods {
    
    int[] score = new int[6];
    
    public Methods(){       
    }
    public int[] chooseMethod1()
    {
        int[] score = new int[6];
        for (int x = 0; x<6; x++){
            int sum = 0;
            Random rand = new Random();
            for(int a = 0; a<4; a++)
            {                
                int i = rand.nextInt(6)+1;
                sum = sum + i;               
                if (sum < 3 || sum > 18)
                {
                    sum = 0;
                    continue;
                }
                if (sum >= 3 && sum<= 18)
                {
                    score[x] = sum;
                    //System.out.print("score["+x+"] = "+score[x]+", ");
                }
            }
            System.out.println("score["+x+"] = "+score[x]);
        }
        return score;
    }
    
    public int[] chooseMethod2()
    {
        int[] score = new int[6];
        int sum = 0;
        while(sum == 0)
        {
            for(int x = 0; x<6; x++)
            {
                for(int s = 0; s<6; s++) // for abilities
                {
                    sum = 0;
                    Random rand = new Random();
                    int[] number = new int[5]; //for choosing 5 number

                    for (int b = 0; b<5; b++)  //for choosing 5 number
                    {
                        int i = rand.nextInt(6)+1;
                        number[b] = i;
                    }

                    for (int c = 0; c<4; c++)  //for choosing 3 of them for summing
                    {        
                        int max_num = number[0];
                        int e = 0;
                        for(int d = 0; d<number.length; d++)
                        {
                            if(number[d]>max_num)
                            {
                                max_num = number[d];
                                e = d;
                            }                    
                        }
                        //maxArray[c] = max_num;
                        number[e] = 0;
                        sum = sum + max_num;
                        //System.out.print("sum = "+ sum + "\n");

                    }
                }
                if (sum < 3 || sum > 18)
                {
                    sum = 0;
                    continue;
                }
                if (sum >= 3 && sum<= 18)
                {
                    score[x] = sum;                    
                }
                System.out.println("score["+x+"] = "+score[x]);                
            }            
        }
        return score;
    }
    
    public int[] chooseMethod3()
    {
        int sum = 0;
        int[] score = new int[6];   
        while (sum == 0)
        {
            for (int x = 0; x<6; x++)
            {
                for(int s = 0; s<6; s++)
                {
                    sum = 0;
                    Random rand = new Random();
                    int[] number = new int[5];
                    //int[] maxArray = new int[3];
                    //ArrayList<Integer> number = new ArrayList<Integer> ();

                    for (int b = 0; b<5; b++)
                    {
                        int i = rand.nextInt(6)+1;
                        number[b] = i;
                    }

                    for (int c = 0; c<4; c++)
                    {        
                        int max_num = number[0];
                        int e = 0;
                        for(int d = 0; d<number.length; d++)
                        {
                            if(number[d]>max_num)
                            {
                                max_num = number[d];
                                e = d;
                            }                    
                        }
                        number[e] = 0;

                        //maxArray[c] = max_num;
                        Random plus = new Random();
                        int[] plusNumber = new int[3];                    
                        for (int f = 0; f<3; f++)
                        {
                            int j = plus.nextInt(3)+1;
                            plusNumber[f] = j;
                        }

                        int maxPlus = plusNumber[0];
                        for(int d = 1; d<plusNumber.length; d++)
                        {
                            if(plusNumber[d]>max_num)
                            {
                                maxPlus = plusNumber[d];
                            }                    
                        }                   
                        sum = sum + max_num+ maxPlus;
                        //System.out.print("sum = "+ sum + "\n");
                    }
                }
                if (sum < 3 || sum > 18)
                {
                    sum = 0;
                    continue;
                }
                if (sum >= 3 && sum<= 18)
                {
                    score[x] = sum;
                    
                } 
                System.out.println("score["+x+"] = "+score[x]);
            }
        }
        return score;        
    }   
}
