package cpsc5000.javadoc;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import javax.swing.JOptionPane;
import java.util.Scanner;
import java.util.Random;
import java.util.*;
/**
 *
 * @author parisa
 */
public class User {
    
    private String username;
    private String password;
    private String emailAddress;    
    private String gender;
    private String line = null;
    
        
    public User()
    {
        this.username = null;
        this.password = null;
        this.emailAddress = null;
    }
    
    
    public void saveUser(String path) throws FileNotFoundException
    {
        PrintWriter outputFile = new PrintWriter(path + this.username + ".txt");
        outputFile.write(this.username + "\n");
        outputFile.write(this.password + "\n");
        outputFile.write(this.emailAddress + "\n");
        outputFile.close();
    }
    
    
    public Scanner loadUser(String username, String path) throws FileNotFoundException
    {        
        String inFile = path + username +".txt";               
        File inputFile = new File(inFile);
        Scanner inputRead = new Scanner(inputFile);
        return inputRead;
    }
    
    public void setUsername(){
        this.username = JOptionPane.showInputDialog("Please enter your user name.");
    }
    
    public void setPassword(){
        this.password = JOptionPane.showInputDialog("Please, enter your password.");
    }
    
    public void setEmailAddress(){
        this.emailAddress = JOptionPane.showInputDialog("Please enter your email address.");
    }

    public String getUserName(){
        return this.username;
    }
    
    public String getPassword(){
        return this.password;
    }
    
    
    public String getEmailAddress(){
        return this.emailAddress;
    }
}        
    

