/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package cpsc5000.javadoc;

import java.util.Random;
import java.util.Scanner;
import javax.swing.JOptionPane;


/**
 *
 * @author parisa
 */
public class Character 
{
    private String nameChar;
    private String gender;
    private String race;
    private int strength;
    private int dexterity;
    private int constitution;
    private int intelligence;
    private int wisdom;
    private int charisma;
    
    public Character(){
    }
    
    public void createCharacter(int choice, String nameChar, String gender)
    {
        this.nameChar = nameChar;
        this.gender = gender;
        this.race=race;
        
        Methods meth = new Methods();
        Score sco = new Score();
        int[] methScore = new int[6];

        if (choice == 1)
        {            
            methScore = meth.chooseMethod1(); 
        }
        if (choice == 2)
        {
            methScore = meth.chooseMethod2(); 
        }
        
        if (choice == 3)
        {
            methScore = meth.chooseMethod3();            
        } 
        
        int[] scoreAbility = sco.getScore(methScore);
        this.strength = scoreAbility[0];
        this.dexterity = scoreAbility[1];
        this.constitution = scoreAbility[2];
        this.intelligence = scoreAbility[3];
        this.wisdom = scoreAbility[4];
        this.charisma = scoreAbility[5];
        
        System.out.print("Strength = "+ strength+ "\n"+ "Dexterity = "+ dexterity +"\n"+
                "Constitution = "+ constitution+"\n"+"Intelligence = " + intelligence + "\n"+
                "Wisdom = "+ wisdom+"\n"+ "Charisma = "+ charisma+ "\n");
    }
}
