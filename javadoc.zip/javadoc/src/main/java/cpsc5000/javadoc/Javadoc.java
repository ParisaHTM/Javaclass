package cpsc5000.javadoc;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import javax.swing.JOptionPane;
import java.io.FileReader;

/**
 *
 * @author parisa
 */
public class Javadoc {

    public static void main(String[] args) throws FileNotFoundException {

        Scanner input = new Scanner(System.in);
        User user = new User();
        Load load = new Load();
        String path = "/Users/parisa/NetBeansProjects/javadoc/";
        int choice = 0;

        while (choice != 7) 
        {

            String menu = JOptionPane.showInputDialog("Please select the number of your option:\n"
                +"1. Create user account\n"
                +"2. Load user account\n"
                +"3. Create character\n"
                +"4. Display character\n"
                +"5. Save character\n"
                +"6. Load character\n"
                +"7. Exit");

            choice = Integer.parseInt(menu);

            //loop over menu 
            if (choice == 1) 
            {
                
                user.setUsername();
                String usernameUser = user.getUserName();
                File userFile = new File(path + usernameUser + ".txt");
                if (userFile.exists()) {
                    JOptionPane.showMessageDialog(null,"This user name already exists. Please choose another user name or load your username");
                    continue;
                }
                user.setPassword();
                user.setEmailAddress();
                
                user.getPassword();
                user.getEmailAddress();
                
                
                user.saveUser(path);
                continue;
            }

            if (choice == 2) 
            {        // load user account
                load.setUsernameLoad();
                String username = load.getUsernameLoad();
                File loadUserPath = new File(path + username + ".txt");
                if (loadUserPath.exists())
                {
                    load.setPasswordLoad();
                    String password = load.getPasswordLoad();                    
                    Scanner id =  user.loadUser(username, path);
                    id.nextLine();
                    String passwordId = id.nextLine();
                    String emailAddressId = id.nextLine();
                    System.out.println(emailAddressId);
                    
                    if (password.equals(passwordId)){
                        continue;                
                    }
                    else
                    {                    
                        String email = JOptionPane.showInputDialog("Your password is wrong.Please enter your email address:");                    
                        if (email.equals(emailAddressId))
                        {
                            JOptionPane.showMessageDialog(null,"It's your password: "+passwordId+"\n");
                            continue;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null, "Your email address is wrong. Please try again!");
                            continue;     
                        }
                    }                    
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"Your user account does not existed. Please create your user name first.");
                    continue;
                }                   
            }                
        
        

            if (choice == 3) 
            {     // create character
                System.out.println("*****");
                String username = load.getUsernameLoad();
                String password = load.getPasswordLoad()
                File loadUserPath = new File(path + username + ".txt");
                System.out.println(path + username + ".txt");
                if (loadUserPath.exists()){
                    Scanner id =  user.loadUser(username, path);
                    id.nextLine();
                    String passwordId = id.nextLine();
                    System.out.println(passwordId);
                    System.out.println(password);
                    
                    if (password.equals(passwordId))
                    {
                        String name = JOptionPane.showInputDialog("Please insert your character name.");
                        String gender = JOptionPane.showInputDialog("Please select character gender(M or F).");

                        int option = 0;
                        while (option == 0)
                        {
                            String menu_2 = JOptionPane.showInputDialog("Please select one of this method for assigning ability scores"+"\n"
                                + "1 - Method 1 = Sum of 3d6. Min/Max = 3/18"+ "\n"
                                + "2 - Method 2 = Sum of best 3 of 5d6. Min/Max = 3/18"+"\n"
                                + "3 - Method 3 = Sum of best 3 of 5d6 plus 1d3. Min/Max = 4/21"+"\n");
                            //Scanner num = new Scanner(System.in);
                            //int choiceNum = num.nextInt();

                            String Race=JOptionPane.showInputDialog("Please select character Race :"+"\n"
                            +"1 - Human"+"\n"
                                +"2 - Elf"+"\n"
                                +"3 - Dwarf"+"\n"
                                +"4 - Gnome"+"\n"
                                +"5 - Halfling"+"\n");

                            String alignments = JOptionPane.showInputDialog("Do you want to choose an alignment for your character?\n1- Yes \n2- No");
                            int choiceAlignment = Integer.parseInt(alignments);

                            if (choiceAlignment == 1){
                                String alignment =JOptionPane.showInputDialog("Please select character's alignment :"+"\n"
                                +"1 - Lawful Good"+"\n"
                                +"2 - Lawful Evil"+"\n"
                                +"3 - Neutral Good"+"\n"
                                +"4 - Neutral Evil"+"\n"
                                +"5 - Chaotic Good"+"\n"
                                +"6 - Chaotic Evil"+"\n");
                            }
                            int choiceNum = Integer.parseInt(menu_2);
                            //int race=Integer.parseInt(Race);
                            Character charc = new Character();
                            charc.createCharacter(choiceNum , name, gender);
                            String agree = JOptionPane.showInputDialog("Are you satisfied with scores?\n1- Yes \n2- No");
                            int choiceAgree = Integer.parseInt(agree);
                            option++;
                            if (choiceAgree == 2)
                            {
                                option = 0;
                                continue;
                            }
                        }
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"Your password is not correct, please try again!");                    
                    }
                }
                else
                {
                   JOptionPane.showMessageDialog(null,"First, you have to log in!"); 
                }
            continue;
            }            
            if (choice == 4){
                
            }
        }
    }
}


